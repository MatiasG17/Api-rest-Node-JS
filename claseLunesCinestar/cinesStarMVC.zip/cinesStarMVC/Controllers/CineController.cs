﻿namespace cinesStarMVC.Controllers
{
    public class CineController
    {
    }
}