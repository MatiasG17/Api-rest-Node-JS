﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cinesStarMVC.Controllers
{
    public class PeliculaController
    {
    }
}