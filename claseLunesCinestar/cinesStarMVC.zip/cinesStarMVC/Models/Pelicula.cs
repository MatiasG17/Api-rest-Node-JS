﻿namespace cinesStarMVC.Models
{
    public class Pelicula
    {
    }
}