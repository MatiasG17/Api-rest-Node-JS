﻿namespace cinesStarMVC.Models
{
    public class Cine
    {
    }
}