﻿public class Usuario
{
    public int Id { get; set; }
    public string Nombres { get; set; }
    public string Correo { get; set; }
    public string Passwordd { get; set; }
}