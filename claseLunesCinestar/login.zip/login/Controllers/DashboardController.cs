﻿using System.Web.Mvc;

public class HomeController : Controller
{
    public ActionResult Index()
    {
        return View();
    }
}
public class DashboardController : Controller
{
    public ActionResult Index()
    {
        return View();
    }
}
